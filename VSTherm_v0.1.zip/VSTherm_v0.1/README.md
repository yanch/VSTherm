# VSTherm: A Virtual Path-based Stochastic Solver for Full-Chip Leakage-Aware Nonlinear Thermal Simulation

`VSTherm` is an accurate and efficient stochastic solver for leakage-aware nonlinear thermal analysis with mixed boundary conditions in 2.5D/3D-IC systems. This repository provides executable binaries tailored to specific cases in the paper "VSTherm: A Virtual Path-based Stochastic Solver for Full-Chip Leakage-Aware Nonlinear Thermal Simulation", along with usage instructions.


**Author:** Yuan Meng, Changhao Yan  
**Affiliation:** Fudan University CAD Lab  
**Version**: v0.1  
**Date:** 2025-09-12


## General Usage Instructions
There are three main categories of use: VSTherm_main and test9_global. VSTherm_main corresponds to caseI-VIII, and test9_global corresponds to case IX. The temperature results of the operation are output in the T.txt file.

## Usage

Preparatory work:
The lib64 folder contains the dependent library files. 
Configure the env.sh file.
source env.sh

1. Generate powermap files.
The power density is placed in the powermap file, with each power density separated by "" and each line separated by "\n".
The powermap in the paper is placed in VSTherm_main/scripts, including "caseA_pm.txt", "caseB_CPU_map.txt", and "caseB_dram_map.txt".

2. Generate the starting point file.
Each line should be written in the format of "x'\t'y'\t'z'\n'". The unit of the coordinate is m.
The starting point file in the paper is placed in VSTherm_main/scripts, including "pointA.txt" and "pointB.txt".

3. Generate a configuration file
Write the configuration file based on the "VSTherm_main/config_example.txt".
"VSTherm_main/config1.txt-config8.txt" correspond to caseI-VIII.
The configuration of case IX has been integrated into the binary file "test9_global/test".

4. Run 
For case I-VIII, run the command "./test configX.txt"
For case IX, run the command "./test"

5. Check the files "T.txt" (Temperature distribution file) and  "Num.txt" (The number of virtual paths distribution file) 

## Output format
T.txt :
"layer row col T"

layer is the index of a layer with a powermap (defined in the config file) 
row = int(y/dy)
col = int(x/dx)
dx = W/nx
dy = L/ny

## Contact
The source code can be obtained via email at 22112020033@m.fudan.edu.cn or yanch@fudan.edu.cn. The user and the organization should be indicated in the email. Commercial use or distribution to third parties is prohibited. Any problems encountered during operation are welcome to be inquired by email 22112020033@m.fudan.edu.cn.