nx = 200
ny = 200
dx = 0.02/nx
dy = 0.02/ny


# size = 150

with open("point.txt","w") as pf:

    for i in range(ny):
        for j in range(nx):

            # if (i >= ny/2 or j >= nx/2):
            #     continue

            x = (j + 0.5) * dx
            y = (i + 0.5) * dy
            pf.write(f'{x:.4e}\t{y:.4e}\t3.5000E-4\n')
            # exit(1)

